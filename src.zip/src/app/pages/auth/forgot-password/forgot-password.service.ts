import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable } from 'rxjs';
import { IOtp , IVerifyOtp, ISubmitNewPassword} from './IForgotPassword';
// import 'rxjs/add/operator/catch'; 

@Injectable()
export class ForgotPasswordService {
    private _urlOtp: string = './assets/otp/otp.json';
    private _urlverifyOtp: string = './assets/otp/verifyOtp.json';
    private _urlSubmitnewPassword: string = './assets/otp/submitNewPass.json';

  constructor(private http: HttpClient) { }

    getOtp(): Observable<IOtp[]>{
      return this.http.get<IOtp[]>(this._urlOtp);                
    }
  

    verifyOtp(): Observable<IVerifyOtp[]>{
      return this.http.get<IVerifyOtp[]>(this._urlverifyOtp);
    }
    submitNewPassword(): Observable<ISubmitNewPassword[]>{
      return this.http.get<ISubmitNewPassword[]>(this._urlSubmitnewPassword);
    }

    errorHandler(error: HttpErrorResponse){
      return Observable.throw(error.message || "Server Error.");
    }

}
