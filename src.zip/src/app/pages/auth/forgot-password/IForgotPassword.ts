export class IOtp {
    public msgId: string;
    public msg: string;
}

export class IVerifyOtp {
    public msgId: string;
    public msg: string;
}

export class ISubmitNewPassword {
    public msgId: string;
    public msg: string;
}