import { Component} from '@angular/core';
import { Router} from '@angular/router';
import { Login } from './Login';
import { LoginService } from './login.service';
import { MatDialog } from '@angular/material';
import { ForgotPasswordComponent } from '../forgot-password/forgot-password.component';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
  providers: [LoginService]
  
})
export class LoginComponent {
    
    login = new Login();
    users: any[];
    valid = true;
    isLoggedIn = 'false';
    wrongCredentails: boolean;
    constructor(private router: Router, private loginService: LoginService, public dialog: MatDialog) {
      
      this.loginService.getUsers()
          .subscribe(users => this.users = users);
    }

    onSubmit() {
      this.valid = true;
      const name = this.login.username;
      sessionStorage.setItem('username', this.login.username);
      const password = this.login.password;
      const user = this.users.filter(currUser => currUser.userName === name && currUser.password === password)[0];
      if (user) {
          this.isLoggedIn = 'true';
          sessionStorage.setItem('isLoggedIn', this.isLoggedIn);
         // this.router.navigate(['/user']);
      } else {
          this.wrongCredentails = true;
          this.isLoggedIn = 'false';
          sessionStorage.setItem('isLoggedIn', this.isLoggedIn);
          this.valid = false;
      }
  }

  openDialog(): void {
    const dialogRef = this.dialog.open(ForgotPasswordComponent, {
      width: '380px',
      data: { username: this.login.username}
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
      
    });
  }

  }

