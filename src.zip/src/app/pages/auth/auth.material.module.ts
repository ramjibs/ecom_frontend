import {NgModule} from "@angular/core";
import { CommonModule } from '@angular/common';
import {
        MatButtonModule, 
        MatInputModule,
        MatDialogModule,
        MatToolbarModule,
        MatTabsModule,
        
} from '@angular/material';


@NgModule({

  imports: [
  CommonModule, 
  MatButtonModule, 
  MatInputModule,
  MatDialogModule,
  MatToolbarModule,
  MatTabsModule,
  
  ],
  exports: [
  CommonModule, 
  MatButtonModule, 
  MatInputModule,
  MatDialogModule, 
  MatToolbarModule,
  MatTabsModule,
  
   ],
})
export class CustomMaterialModule { }

