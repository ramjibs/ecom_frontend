import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-setting-sketch',
  templateUrl: './admin-setting-sketch.component.html',
  styleUrls: ['./admin-setting-sketch.component.css']
})
export class AdminSettingSketchComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
