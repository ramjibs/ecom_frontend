import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminSettingSketchComponent } from './admin-setting-sketch.component';

describe('AdminSettingSketchComponent', () => {
  let component: AdminSettingSketchComponent;
  let fixture: ComponentFixture<AdminSettingSketchComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdminSettingSketchComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminSettingSketchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
