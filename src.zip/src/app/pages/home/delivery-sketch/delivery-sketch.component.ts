import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-delivery-sketch',
  templateUrl: './delivery-sketch.component.html',
  styleUrls: ['./delivery-sketch.component.css']
})
export class DeliverySketchComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
