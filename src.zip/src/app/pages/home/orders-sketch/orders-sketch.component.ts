import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-orders-sketch',
  templateUrl: './orders-sketch.component.html',
  styleUrls: ['./orders-sketch.component.css']
})
export class OrdersSketchComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
