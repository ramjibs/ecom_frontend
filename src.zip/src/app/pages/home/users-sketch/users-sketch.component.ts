import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-users-sketch',
  templateUrl: './users-sketch.component.html',
  styleUrls: ['./users-sketch.component.css']
})
export class UsersSketchComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
