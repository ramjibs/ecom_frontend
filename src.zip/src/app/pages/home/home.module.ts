import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { HomeRoutingModule } from './home-routing.module';
import { DeliverySketchComponent } from './delivery-sketch/delivery-sketch.component';
import { UsersSketchComponent } from './users-sketch/users-sketch.component';
import { OrdersSketchComponent } from './orders-sketch/orders-sketch.component';
import { AdminSettingSketchComponent } from './admin-setting-sketch/admin-setting-sketch.component';

@NgModule({
  declarations: [DeliverySketchComponent, UsersSketchComponent, OrdersSketchComponent, AdminSettingSketchComponent],
  imports: [
    CommonModule,
    HomeRoutingModule
  ]
})
export class HomeModule { }
